﻿using AppForExam.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AppForExam.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageProducts.xaml
    /// </summary>
    public partial class PageProducts : Page
    {
        public PageProducts()
        {
            InitializeComponent();

            ClassHelper.spMenu.Visibility = Visibility.Visible;
            ClassHelper.CurrentUser_FIO.Text = ClassHelper.CurrentUser != null ? ClassHelper.CurrentUser.FIO : "Гость";

            List<Manufacturers> cmbList = new List<Manufacturers>() { new Manufacturers() { Name = "Все производители" } };
            cmbList.AddRange(ClassHelper.db.Manufacturers);
            cmbFilter.ItemsSource = cmbList;
            cmbFilter.SelectedIndex = 0;

            if (ClassHelper.CurrentUser != null && ClassHelper.CurrentUser.Roles.Name == "Администратор")
            {
                miAdd.Visibility = Visibility.Visible;
                miEdit.Visibility = Visibility.Visible;
                miDelete.Visibility = Visibility.Visible;
            }
        }

        private void CmbFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Manufacturers item = cmbFilter.SelectedItem as Manufacturers;
            if (item == null || item.Name == "Все производители") lstvProducts.ItemsSource = ClassHelper.db.Products.ToList();
            else lstvProducts.ItemsSource = ClassHelper.db.Products.Where(x => x.Manufacturers.Name == item.Name).ToList();
            CountItems.Text = $"{lstvProducts.Items.Count} из {ClassHelper.db.Products.Count()}";
        }

        private void TxbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            string search = txbSearch.Text.ToLower();
            List<Products> list = ClassHelper.db.Products.ToList();
            if (search.Count() != 0) lstvProducts.ItemsSource = list.Where(x => x.Name.ToLower().Contains(search) || x.Description.ToLower().Contains(search) || x.Manufacturer.ToLower().Contains(search) || x.Price.ToString().ToLower().Contains(search) || x.QuantityInStock.ToString().ToLower().Contains(search));
            else lstvProducts.ItemsSource = list;
            CountItems.Text = $"{lstvProducts.Items.Count} из {list.Count()}";
        }

        private void MenuAddOrEdit_Click(object sender, RoutedEventArgs e)
        {
            if (((MenuItem)sender).Header.ToString() == "Добавить") ClassHelper.frmObj.Navigate(new AddEditPageProduct(null));
            else if (lstvProducts.SelectedItem is Products p) ClassHelper.frmObj.Navigate(new AddEditPageProduct(p));
            else MessageBox.Show("Выберите продукт для изменения.", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Warning);

        }

        private void MenuUpdate_Click(object sender, RoutedEventArgs e)
        {
            lstvProducts.ItemsSource = ClassHelper.db.Products.ToList();
            CountItems.Text = $"{lstvProducts.Items.Count} из {ClassHelper.db.Products.Count()}";
        }

        private void MenuSort_Click(object sender, RoutedEventArgs e)
        {
            MenuItem menuItemParent = (MenuItem)((MenuItem)sender).Parent;
            MenuItem menuItem = (MenuItem)sender;
            if (menuItemParent.Header.ToString() == "По наименованию")
            {
                if (menuItem.Header.ToString() == "От А до Я") lstvProducts.ItemsSource = ClassHelper.db.Products.OrderBy(x => x.Name).ToList();
                else lstvProducts.ItemsSource = ClassHelper.db.Products.OrderByDescending(x => x.Name).ToList();
            }
            else
            {
                if (menuItem.Header.ToString() == "По возрастанию") lstvProducts.ItemsSource = ClassHelper.db.Products.OrderBy(x => x.Price).ToList();
                else lstvProducts.ItemsSource = ClassHelper.db.Products.OrderByDescending(x => x.Price).ToList();
            }
            CountItems.Text = $"{lstvProducts.Items.Count} из {ClassHelper.db.Products.Count()}";
        }

        private void MenuDelete_Click(object sender, RoutedEventArgs e)
        {
            if (!(lstvProducts.SelectedItem is Products p))
            {
                MessageBox.Show($"Выберите продукт для удаления.", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (MessageBox.Show($"Вы точно хотите удалить запись №{p.idProduct}?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {

                    //if (Продукт есть в заказе)
                    //{
                    //    MessageBox.Show($"Продукт №{p.idProduct} нельзя удалить, т.к. он есть в заказе!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Warning);
                    //    return;
                    //}
                    // УДАЛИТЬ ВСЕ ДОП. ТОВАРЫ!
                    ClassHelper.db.Products.Remove(p);
                    ClassHelper.db.SaveChanges();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
            }
            else return;
            MessageBox.Show("Данные удалены!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
            lstvProducts.ItemsSource = ClassHelper.db.Products.ToList();
            CountItems.Text = $"{lstvProducts.Items.Count} из {ClassHelper.db.Products.Count()}";
        }
    }
}
