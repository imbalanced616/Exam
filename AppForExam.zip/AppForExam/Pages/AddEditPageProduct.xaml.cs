﻿using AppForExam.Classes;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AppForExam.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditPageProduct.xaml
    /// </summary>
    public partial class AddEditPageProduct : Page
    {
        private readonly Products _currentItem = new Products();
        public AddEditPageProduct(Products selectedItem)
        {
            InitializeComponent();
            if (selectedItem != null)
            {
                _currentItem = selectedItem;
                txtTitle.Text = "Изменение продукта";
                btnAddEdit.Content = "Изменить";
            }
            cmbManufacturers.ItemsSource = ClassHelper.db.Manufacturers.ToList();
            //if (_currentItem.Photo != null) btnImageClear.Visibility = Visibility.Visible;
            DataContext = _currentItem;
        }

        private void ImageLoad_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ClickCount == 2)
            {
                try
                {
                    OpenFileDialog dlg = new OpenFileDialog { Filter = "Файлы изображений (*.png, *.jpg, *.jpeg, *.bmp)|*.png;*.jpg;*.jpeg;*.bmp|Все файлы (*.*)|*.*", Title = "Выберите фото/изображение продукта" };
                    if (dlg.ShowDialog() == true)
                    {
                        imageUser.Source = new BitmapImage(new Uri(dlg.FileName.ToString()));
                        FileStream fs = new FileStream(dlg.FileName.ToString(), FileMode.Open, FileAccess.Read);
                        BinaryReader br = new BinaryReader(fs);
                        _currentItem.Photo = br.ReadBytes((int)fs.Length);
                    }
                }
                catch (Exception ex) { MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error); }
            }
        }

        private void ImageLoad_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog dlg = new OpenFileDialog { Filter = "Файлы изображений (*.png, *.jpg, *.jpeg, *.bmp)|*.png;*.jpg;*.jpeg;*.bmp|Все файлы (*.*)|*.*", Title = "Выберите фото/изображение продукта" };
                if (dlg.ShowDialog() == true)
                {
                    imageUser.Source = new BitmapImage(new Uri(dlg.FileName.ToString()));
                    FileStream fs = new FileStream(dlg.FileName.ToString(), FileMode.Open, FileAccess.Read);
                    BinaryReader br = new BinaryReader(fs);
                    _currentItem.Photo = br.ReadBytes((int)fs.Length);
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error); }
        }

        private void ImageClear_Click(object sender, RoutedEventArgs e)
        {
            _currentItem.Photo = null;
            imageUser.Source = (ImageSource)FindResource("UnknownProduct");
        }

        private void BtnAddOrEdit_Click(object sender, RoutedEventArgs e)
        {
            bool add = false;
            StringBuilder error = new StringBuilder();
            if (string.IsNullOrWhiteSpace(_currentItem.Name)) error.AppendLine("Укажите название продукта.");
            if (string.IsNullOrWhiteSpace(_currentItem.Description)) error.AppendLine("Укажите описание продукта.");
            if (string.IsNullOrWhiteSpace(_currentItem.idManufacturer.ToString())) error.AppendLine("Укажите производителя.");
            if (string.IsNullOrWhiteSpace(_currentItem.Price.ToString())) error.AppendLine("Укажите цену продукта.");
            if (string.IsNullOrWhiteSpace(_currentItem.QuantityInStock.ToString())) error.AppendLine("Укажите количество продукта на складе.");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString(), "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (_currentItem.idProduct == 0)
            {
                ClassHelper.db.Products.Add(_currentItem);
                add = true;
            }
            try
            {
                ClassHelper.db.SaveChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (add) MessageBox.Show("Новый продукт успешно добавлен!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
            else MessageBox.Show("Продукт успешно изменён!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
            ClassHelper.frmObj.Navigate(new PageProducts());
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            ClassHelper.frmObj.Navigate(new PageProducts());
        }
    }
}
