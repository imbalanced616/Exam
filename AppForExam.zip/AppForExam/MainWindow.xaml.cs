﻿using AppForExam.Classes;
using AppForExam.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AppForExam
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            ClassHelper.spMenu = spMenu;
            ClassHelper.CurrentUser_FIO = CurrentUser_FIO;
            ClassHelper.frmObj = FrameWindow;
            ClassHelper.frmObj.Navigate(new LoginPage());
        }

        private void BtnSignOut_Click(object sender, RoutedEventArgs e)
        {
            ClassHelper.spMenu.Visibility = Visibility.Collapsed;
            ClassHelper.CurrentUser = null;
            ClassHelper.CurrentUser_FIO.Text = "";
            ClassHelper.frmObj.Navigate(new LoginPage());
        }

        private void BtnProducts_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
