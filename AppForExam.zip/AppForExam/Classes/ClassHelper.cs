﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace AppForExam.Classes
{
    public class ClassHelper
    {
        public static Frame frmObj;

        public static ProductsEntities db = new ProductsEntities();

        public static Users CurrentUser;
        public static TextBlock CurrentUser_FIO;
        public static StackPanel spMenu;
    }
}
